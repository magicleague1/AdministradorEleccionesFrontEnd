import React from 'react';
import "../css/inicio.css"

const Inicio = () => {
  return (
    <div className='Inicio1'>
         <div className="inicio-container">
          <div className='LetrasDescripcion'>
          <h2 className='Letras2'>Bienvenido al sistema de administracion de elecciones </h2>
          <h2 className='Letras1'> FACULTAD DE CIENCIAS Y TECNOLOGIA</h2>
          </div>
            
        </div>
    </div>
    
  );
};



export default Inicio;
