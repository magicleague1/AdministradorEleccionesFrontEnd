import React,{useState} from "react";
import "../css/MenuIzquierdo.css"
import Logo from '../assets/logo.png';
import CrearElecciones from './CrearElecciones';
import Inicio from './Inicio';
import VerElecciones from './VerElecciones'; 
import AsignacionComite from "./AsignacionComite";
import PartidosPoliticos from "./PartidosPoliticos";

function MenuIzquierdo() {
    const [mostrarCrearEleccion, setMostrarCrearEleccion] = useState(false);
    const [mostrarInicio, setMostrarInicio] = useState(true);  // Mostrar Inicio por defecto
    const [mostrarVerElecciones, setMostrarVerElecciones] = useState(false);  // Estado para mostrar VerElecciones
    const [mostrarVerComite, setMostrarVerComite] = useState(false);
    const [mostrarVerPartido, setMostrarPartido] = useState(false);
    const [menuDesplegableCrearEleccion, setMenuDesplegableCrearEleccion] = useState(false);
    const handleCrearEleccionClick = () => {
      setMostrarCrearEleccion(true);
      setMostrarInicio(false);
      setMostrarVerElecciones(false);  // Oculta VerElecciones al hacer clic en Crear Elección
      setMostrarVerComite(false); 
      setMostrarPartido(false);   
    };
  
    const handleInicioClick = () => {
      setMostrarCrearEleccion(false);
      setMostrarInicio(true);
      setMostrarVerElecciones(false);  // Oculta VerElecciones al hacer clic en Inicio
      setMostrarVerComite(false);
      setMostrarPartido(false);
    };
  
    const handleVerEleccionesClick = () => {
      setMostrarCrearEleccion(false);
      setMostrarInicio(false);
      setMostrarVerElecciones(true);
      setMostrarVerComite(false);
      setMostrarPartido(false);
        // Muestra VerElecciones al hacer clic en Ver Elecciones Activas
    };
    const handleVerComiteClick = () => {
        setMostrarCrearEleccion(false);
        setMostrarInicio(false);
        setMostrarVerElecciones(false);
        setMostrarVerComite(true);
        setMostrarPartido(false);
          // Muestra VerElecciones al hacer clic en Ver Elecciones Activas
      };
      const handleVerPartidoClick = () => {
        setMostrarCrearEleccion(false);
        setMostrarInicio(false);
        setMostrarVerElecciones(false);
        setMostrarVerComite(false);
        setMostrarPartido(true);
          // Muestra VerElecciones al hacer clic en Ver Elecciones Activas
      };
      const toggleMenuDesplegable = (opcion) => {
        switch (opcion) {
          
          case 'Proceso Electoral':
            setMenuDesplegableCrearEleccion(!menuDesplegableCrearEleccion);
            break;
          default:
            break;
        }
      };
    return(
        <div class="wrapper">
            <div class="sidebar">
                <div class="profile">
                    <img src={Logo} alt="profile_picture"/>
                    <h3>Administrador de elecciones  </h3>
                    <b> FCyT </b>

                </div>
                
                    <ul className='listaSidebar' >

                                        <li  className="row" id={ mostrarInicio ? "active" : ""}
                                        onClick=
                                            {handleInicioClick}
                                        >
                                            
                                                <span class="icon"><i class="fas fa-home"></i></span>
                                                <span class="item">Inicio</span>
                                                
                                        </li>
                                        <li className="row" onClick={() => toggleMenuDesplegable('Proceso Electoral')}>
                                            <span className="icon"><i className="fas fa-home"></i></span>
                                            <span className="item">Proceso Electoral</span>
                                        </li>
                                        {menuDesplegableCrearEleccion && (
                                            <div className="submenu">
                                            
                                            <li  className="Ocultos" id={ mostrarCrearEleccion ? "active" : ""}
                                                   onClick={() => {
                                                    handleCrearEleccionClick();
                                                    toggleMenuDesplegable('Proceso Electoral');
                                                  }}

                                            >
                                            
                                                <span class="icon"><i class="fas fa-home"></i></span>
                                                <span class="item">Crear Proceso Electoral</span>
                                                
                                        </li>
                                        <li  className="Ocultos" id={ mostrarVerElecciones ? "active" : ""}
                                        onClick={() => {
                                            handleVerEleccionesClick();
                                            toggleMenuDesplegable('Proceso Electoral');
                                          }}
                                        >
                                            
                                                <span class="icon"><i class="fas fa-home"></i></span>
                                                <span class="item">Procesos Electorales Activos</span>
                                                
                                        </li>
                                            </div>
                                        )}
                                       
                                        <li  className="row" id={ mostrarVerComite ? "active" : ""}
                                        onClick=
                                            {handleVerComiteClick}
                                        >
                                            
                                                <span class="icon"><i class="fas fa-home"></i></span>
                                                <span class="item">Comite Electoral</span>
                                                
                                        </li>
                                        <li  className="row" id={ mostrarVerPartido ? "active" : ""}
                                        onClick=
                                            {handleVerPartidoClick}
                                        >
                                            
                                                <span class="icon"><i class="fas fa-home"></i></span>
                                                <span class="item">Partidos Politicos</span>
                                                
                                        </li>
                                    
                        
                    </ul>
                
                
            </div>
            <div className="SegundoDivMenu">
                    {mostrarCrearEleccion && <CrearElecciones />}
                    {mostrarInicio && <Inicio />}
                    {mostrarVerElecciones && <VerElecciones lista = {mostrarVerElecciones}/>} 
                    {mostrarVerComite && <AsignacionComite/>}
                    {mostrarVerPartido && <PartidosPoliticos/>}
            </div>
        
        </div>
         
        

    );
}
   
export default MenuIzquierdo;    