export const Sidebardatos = [

    {
        title: "Inicio",
        path: "/Inicio"

    },
    {
        title: "Proceso Electoral",
        path: "/ProcesoElectoral"

    },
    {
        title: "Elecciones Activas",
        path: "/EleccionesActivas"

    },
    {
        title: "Comite Electoral",
        path: "/ComiteElectoral"

    },

]